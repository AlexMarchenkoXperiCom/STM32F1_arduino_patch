#include "Wire.h"

void OLED::_convert_float(char *buf, double num, int width, byte prec)
{
	char format[10];
	
	sprintf(format, "%%%i.%if", width, prec);
	sprintf(buf, format, num);
}


void OLED::_initTWI()
{
    Wire.begin();
}

void OLED::update()
{
	//noInterrupts();
	_sendTWIcommand(SSD1306_SET_COLUMN_ADDR);
	_sendTWIcommand(0);
	_sendTWIcommand(127);

	_sendTWIcommand(SSD1306_SET_PAGE_ADDR);
	_sendTWIcommand(0);
	_sendTWIcommand(7);
	
	if (_use_hw)					// Send TWI Start
	{
		Wire.beginTransmission(SSD1306_ADDR);
		Wire.write(SSD1306_DATA_CONTINUE);
	}
	else
	{
		_sendStart(SSD1306_ADDR<<1);
		_waitForAck();
		_writeByte(SSD1306_DATA_CONTINUE);
		_waitForAck();
	}

	for (int b=0; b < sizeof(scrbuf); b++)		// Send data
	{
		if (_use_hw)
		{
		    // I2C driver has small buffer. So we dividing our data on chunks
		    // each one 32 bytes length.
		    if (Wire.tx_available() > 0)
		    {
		        Wire.write(scrbuf[b]);
		    }
		    else
		    {
		        Wire.endTransmission();
                // Wait for I2C to not be busy, then retry.
                do {
                } while(Wire.get_intf()->regs->SR2 & I2C_SR2_BUSY);

                Wire.beginTransmission(SSD1306_ADDR);
                Wire.write(SSD1306_DATA_CONTINUE);
                if (Wire.tx_available() > 0)
                {
                    Wire.write(scrbuf[b]);
                 }
            }
		}
		else
		{
			_writeByte(scrbuf[b]);
			_waitForAck();
		}
	}

	if (_use_hw)					// Send TWI Stop
	{
		Wire.endTransmission();
	}
	else
	{
		_sendStop();
	}
}

void OLED::_sendTWIcommand(uint8_t value)
{
	if (_use_hw)
	{
        	Wire.beginTransmission(SSD1306_ADDR);
        	Wire.write(SSD1306_COMMAND);
        	Wire.write(value);
        	Wire.endTransmission();
	}
	else
	{
		_sendStart(SSD1306_ADDR<<1);
		_waitForAck();
		_writeByte(SSD1306_COMMAND);
		_waitForAck();
		_writeByte(value);
		_waitForAck();
		_sendStop();
	}
}
